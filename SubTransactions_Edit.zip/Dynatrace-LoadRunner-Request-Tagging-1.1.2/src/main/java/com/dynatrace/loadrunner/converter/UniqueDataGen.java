package com.dynatrace.loadrunner.converter;

import java.util.concurrent.atomic.AtomicLong;

public class UniqueDataGen {
	long i;
	       AtomicLong c = new AtomicLong(0);

//	      public void increment() {
//	         c.incrementAndGet();
//	      }

	      public long value() {
	    	 i = c.incrementAndGet() + 2;
	         return i+2;
	      }
}
